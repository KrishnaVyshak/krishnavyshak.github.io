import io
import time
from PyQt5 import QtWidgets, uic, QtGui
import sys
import keyboard
import pyttsx3
from threading import *
import speech_recognition as sr
import re
import cv2
import pytesseract
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QMessageBox, QInputDialog, QLineEdit, QTableWidgetItem, QShortcut
import winsound


screen = """<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <author>Krishnavyshak</author>
 <class>MainWindow</class>
 <widget class="QMainWindow" name="MainWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>665</width>
    <height>927</height>
   </rect>
  </property>
  <property name="minimumSize">
   <size>
    <width>665</width>
    <height>927</height>
   </size>
  </property>
  <property name="maximumSize">
   <size>
    <width>665</width>
    <height>927</height>
   </size>
  </property>
  <property name="windowTitle">
   <string>HELPER - By Krishnavyshak R.</string>
  </property>
  <property name="windowIcon">
   <iconset>
    <normaloff>helper_icon.ico</normaloff>helper_icon.ico</iconset>
  </property>
  <widget class="QWidget" name="centralwidget">
   <widget class="QLabel" name="label">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>0</y>
      <width>221</width>
      <height>51</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>20</pointsize>
     </font>
    </property>
    <property name="text">
     <string>HELPER</string>
    </property>
   </widget>
   <widget class="QLabel" name="label_2">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>75</y>
      <width>191</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>Insert Note:</string>
    </property>
   </widget>
   <widget class="QTextEdit" name="note_input">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>120</y>
      <width>641</width>
      <height>191</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>13</pointsize>
     </font>
    </property>
   </widget>
   <widget class="QPushButton" name="start_read_button">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>320</y>
      <width>641</width>
      <height>44</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Start</string>
    </property>
   </widget>
   <widget class="QPushButton" name="clear">
    <property name="geometry">
     <rect>
      <x>508</x>
      <y>65</y>
      <width>144</width>
      <height>44</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>13</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Clear</string>
    </property>
   </widget>
   <widget class="QLabel" name="label_3">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>430</y>
      <width>371</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>Known Words List:</string>
    </property>
   </widget>
   <widget class="QPushButton" name="delete_2">
    <property name="geometry">
     <rect>
      <x>330</x>
      <y>660</y>
      <width>321</width>
      <height>44</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Remove Selected</string>
    </property>
   </widget>
   <widget class="QPushButton" name="add">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>660</y>
      <width>311</width>
      <height>44</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Add New</string>
    </property>
   </widget>
   <widget class="QListWidget" name="list">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>470</y>
      <width>641</width>
      <height>181</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
   </widget>
   <widget class="QLabel" name="label_4">
    <property name="geometry">
     <rect>
      <x>30</x>
      <y>730</y>
      <width>391</width>
      <height>41</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>Voice Speed (max 100):</string>
    </property>
   </widget>
   <widget class="QDial" name="dial">
    <property name="geometry">
     <rect>
      <x>450</x>
      <y>720</y>
      <width>191</width>
      <height>171</height>
     </rect>
    </property>
    <property name="cursor">
     <cursorShape>OpenHandCursor</cursorShape>
    </property>
    <property name="mouseTracking">
     <bool>true</bool>
    </property>
    <property name="styleSheet">
     <string notr="true"/>
    </property>
    <property name="maximum">
     <number>100</number>
    </property>
    <property name="value">
     <number>98</number>
    </property>
    <property name="invertedAppearance">
     <bool>false</bool>
    </property>
    <property name="invertedControls">
     <bool>true</bool>
    </property>
    <property name="wrapping">
     <bool>false</bool>
    </property>
    <property name="notchTarget">
     <double>0.000000000000000</double>
    </property>
    <property name="notchesVisible">
     <bool>true</bool>
    </property>
   </widget>
   <widget class="QLabel" name="dial_value">
    <property name="geometry">
     <rect>
      <x>370</x>
      <y>730</y>
      <width>61</width>
      <height>41</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>10</string>
    </property>
   </widget>
   <widget class="QCheckBox" name="checkbox">
    <property name="geometry">
     <rect>
      <x>30</x>
      <y>780</y>
      <width>241</width>
      <height>28</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Remember voice speed</string>
    </property>
   </widget>
   <widget class="QLabel" name="label_5">
    <property name="geometry">
     <rect>
      <x>140</x>
      <y>20</y>
      <width>231</width>
      <height>24</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>10</pointsize>
     </font>
    </property>
    <property name="styleSheet">
     <string notr="true">color: rgb(172, 172, 172);</string>
    </property>
    <property name="text">
     <string>By Krishnavyshak R.</string>
    </property>
   </widget>
   <widget class="QLabel" name="label_6">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>880</y>
      <width>441</width>
      <height>41</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>8</pointsize>
     </font>
    </property>
    <property name="styleSheet">
     <string notr="true">color: rgb(135, 135, 135);</string>
    </property>
    <property name="text">
     <string>Don't close the window when reading is in progress.</string>
    </property>
   </widget>
   <widget class="QLabel" name="label_7">
    <property name="geometry">
     <rect>
      <x>30</x>
      <y>825</y>
      <width>101</width>
      <height>41</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>Voice</string>
    </property>
   </widget>
   <widget class="QPushButton" name="fromImg">
    <property name="geometry">
     <rect>
      <x>355</x>
      <y>65</y>
      <width>144</width>
      <height>44</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>13</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
    <property name="text">
     <string>Use image</string>
    </property>
   </widget>
   <widget class="QLabel" name="last_word_lab">
    <property name="geometry">
     <rect>
      <x>10</x>
      <y>384</y>
      <width>201</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>last word</string>
    </property>
    <property name="alignment">
     <set>Qt::AlignCenter</set>
    </property>
   </widget>
   <widget class="QLabel" name="curr_word">
    <property name="geometry">
     <rect>
      <x>230</x>
      <y>373</y>
      <width>201</width>
      <height>51</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe UI Emoji</family>
      <pointsize>18</pointsize>
     </font>
    </property>
    <property name="text">
     <string>currenet word</string>
    </property>
    <property name="alignment">
     <set>Qt::AlignCenter</set>
    </property>
   </widget>
   <widget class="QLabel" name="next_word_lab">
    <property name="geometry">
     <rect>
      <x>450</x>
      <y>384</y>
      <width>201</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>14</pointsize>
     </font>
    </property>
    <property name="text">
     <string>next word</string>
    </property>
    <property name="alignment">
     <set>Qt::AlignCenter</set>
    </property>
   </widget>
   <widget class="QLabel" name="words_written">
    <property name="geometry">
     <rect>
      <x>460</x>
      <y>20</y>
      <width>191</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <family>Segoe MDL2 Assets</family>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="text">
     <string>000 words written</string>
    </property>
    <property name="alignment">
     <set>Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter</set>
    </property>
   </widget>
   <widget class="QComboBox" name="voice_select">
    <property name="geometry">
     <rect>
      <x>130</x>
      <y>830</y>
      <width>241</width>
      <height>31</height>
     </rect>
    </property>
    <property name="font">
     <font>
      <pointsize>12</pointsize>
     </font>
    </property>
    <property name="cursor">
     <cursorShape>PointingHandCursor</cursorShape>
    </property>
   </widget>
  </widget>
 </widget>
 <resources/>
 <connections/>
</ui>



<!-- Author - Krishnavyshak -->

"""


class Ui(QtWidgets.QMainWindow):
   def __init__(self):
      super(Ui, self).__init__()
      self.stop_thread = False
      self.r = sr.Recognizer()
      

      f = io.StringIO(screen)
      uic.loadUi(f, self)
      self.checkbox.hide()
      
      with open("res/config.helper", "r") as f:

         lines = f.read().splitlines()
         # # print(lines)
         self.shouldUseFromFile = lines[1]
         self.theme_status = lines[3]
         
         QtGui.QFontDatabase.addApplicationFont('res/fonts/manrope_medium.ttf')
         QtGui.QFontDatabase.addApplicationFont('res/fonts/manrope_xtrabold.ttf')
         QtGui.QFontDatabase.addApplicationFont('res/fonts/Gilroy-Medium.ttf')

         self.theme = "" if not self.theme_status else open("res/theme.helper", "r").read()


        # find the widgets in the xml file
      '''
         if lines[2] == "Male":
            self.male.setChecked(True)
            self.female.setChecked(False)
            self.voice_gender = 0
         elif lines[2] == "Female":
            self.female.setChecked(True)
            self.male.setChecked(False)
            self.voice_gender = 1
      '''
      # Variables
      note = ""
      self.known_words_list = []
      self.current_word = ""
      self.language = 'en'
      self.isReading = False
      self.voice_index = 0

      self.setStyleSheet(self.theme)

      with open("res/known_words_list.helper", "r") as f:
         lines = f.read().split(",\n")
         self.known_words_list = lines
         self.known_words_list.pop(len(self.known_words_list) - 1)
         # print(self.known_words_list)

      # print("ss" + self.shouldUseFromFile)
      if str(self.shouldUseFromFile) == "True":
         self.change_dial_value
         self.checkbox.setChecked(True)
         self.checkBoxState = True

         with open("res/config.helper", "r") as f:
            lines = f.read().split("\n")
            self.tessPath = lines[5]
            pytesseract.pytesseract.tesseract_cmd = self.tessPath
            self.voice_index = lines[2]
            self.newVoiceRate = lines[0]
            self.checkBoxState = bool(lines[1])
            self.totalWords = int(lines[4])
            self.voices_list = lines[6].split(', ')
            self.voice_select.addItems(self.voices_list)
            self.dial.setValue(int(self.newVoiceRate))
            self.voice_select.setCurrentIndex(int(self.voice_index))

            # print(lines[0] + "f")

            self.dial_value.setText(str(self.newVoiceRate))


      else:
         self.checkbox.setChecked(False)
         self.checkBoxState = False
         self.newVoiceRate = self.dial.value()
         self.dial_value.setText(str(self.newVoiceRate))

      self.additem = QShortcut(QKeySequence('Ctrl+m'), self)
      self.additem.activated.connect(self.add_word)

      self.loadtheme = QShortcut(QKeySequence('Ctrl+f'), self)
      self.loadtheme.activated.connect(self.load_theme)
      
      self.checkbox.stateChanged.connect(self.checkBoxChangedAction)
      '''self.male.stateChanged.connect(self.maleChecked)
      self.female.stateChanged.connect(self.femaleChecked)'''
      
      self.voice_select.currentIndexChanged.connect(self.on_voice_changed)
      
      self.engine = pyttsx3.init()
      # self.check_alt_press()
      self.voices = self.engine.getProperty('voices')
      self.words_written.setText(f"{self.totalWords} words written")

      # self.start_read_button.clicked.connect(self.read)
      self.dial_value.setText(str(self.newVoiceRate))
      self.dial.valueChanged.connect(self.change_dial_value)
      self.start_read_button.clicked.connect(self.thread)
      # self.save_button.clicked.connect(self.update_speed_file)
      self.clear.clicked.connect(self.clear_input)
      self.add.clicked.connect(self.get_new)
      self.list.itemClicked.connect(self.buffer_item)
      self.delete_2.clicked.connect(self.remove)
      self.fromImg.clicked.connect(self.getImage)

      # # print("sis" + self.known_words_list[-1])
      for i in self.known_words_list:
         self.list.addItem(i)
      # print("nvvvr " + str(self.newVoiceRate))
      self.engine.setProperty('rate', int(self.newVoiceRate))

      # self.list.setCurrentItem(str(self.known_words_list[0]))


   '''def maleChecked(self):
      if self.male.isChecked():
         self.voice_gender = 0
         self.female.setChecked(False)
      else:
         self.voice_gender = 1
         self.female.setChecked(True)

   def femaleChecked(self):
      if self.female.isChecked():
         self.voice_gender = 1
         self.male.setChecked(False)
      else:
         self.voice_gender = 0
         self.male.setChecked(True)'''
   
   def on_voice_changed(self, value):
       self.voice_index = value

   def buffer_item(self, item):
      try:
         self.remove = item.text()
      except:
         self.beep()

   def clear_input(self):
      self.note_input.setText("")

   def thread(self):
      t1 = Thread(target=self.read)
      t1.start()
      

   def remove(self):
      try:
         if len(self.known_words_list) != 0:
            selected = str(self.known_words_list[self.known_words_list.index(self.remove)])
            # print(self.known_words_list.index(self.remove))
            self.list.takeItem(self.known_words_list.index(self.remove))
            self.known_words_list.pop(self.known_words_list.index(self.remove))
            # print(self.known_words_list)
            # self.list.takeItem()
      except:
         winsound.PlaySound("SystemExit", winsound.SND_ALIAS)

   def add_word(self):
      text = self.current_word.replace(",", "").replace('.', '')
      if len(text) > 8:
         if not text in self.known_words_list:
            self.known_words_list.append(text.lower())
            self.list.clear()
            for i in self.known_words_list:
               self.list.addItem(str(i))

         else:
            winsound.PlaySound("SystemExit", winsound.SND_ALIAS)
      else:
         winsound.PlaySound("SystemExit", winsound.SND_ALIAS)

   def load_theme(self):
      self.theme = "" if not self.theme_status else open("res/theme.helper", "r").read()
      self.setStyleSheet(self.theme)

   def getImage(self):
      options = QtWidgets.QFileDialog.Options()
      options = QtWidgets.QFileDialog.DontUseNativeDialog
      try:
         self.fileName, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open an image", "",
                                                                  "All Files (*);;Image Files (*.jpg);;Image Files (*.png)",
                                                                  options=options)
      except:
         print("Error from user")
      # print(self.fileName)
      if self.fileName != "":
          self.extractText()

   def extractText(self):
      config = ('-l eng --oem 1 --psm 3')
      img = cv2.imread(self.fileName, cv2.IMREAD_COLOR)
      # Run tesseract OCR on image
      text = pytesseract.image_to_string(img, config=config)
      # Print recognized text
      self.note_input.setPlainText(str(text))

   def get_new(self):
      dlg = QInputDialog(self)
      dlg.setInputMode(QInputDialog.TextInput)
      dlg.setWindowTitle("Add a word")
      dlg.setLabelText("Add new word (minimum 9 character):")
      dlg.resize(500, 100)
      ok = dlg.exec_()
      text = dlg.textValue()
      # text, okPressed = QInputDialog.getText(self, "Get text","Add new word (minimum 8 character)", QLineEdit.Normal, "").resize(500, 100)
      if ok and len(text) > 8:
         self.known_words_list.append(text)
         self.list.clear()
         for i in self.known_words_list:
            self.list.addItem(str(i))

      else:
         msg = QMessageBox()
         msg.setIcon(QMessageBox.Critical)

         # setting message for Message Box
         msg.setText("Error")

         # setting Message box window title
         msg.setWindowTitle("Error")
         msg.setText("You must enter a word with at least 9 characters.")
         msg.setWindowIcon(QtGui.QIcon('helper_icon.ico'))

         # declaring buttons on Message Box
         msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)

         # start the app
         retval = msg.exec_()

   def closeEvent(self, event):
      self.stop_thread = True
      with open("res/config.helper", "w") as f:
         f.write(str(self.dial.value()) if self.checkBoxState else "96")
         f.write("\nTrue" if self.checkBoxState else "\nFalse")
         f.write(f'\n{self.voice_index}')
         f.write("\nTrue" if self.theme_status else "\nFalse")
         f.write(f"\n{self.totalWords}")
         f.write(f'\n{self.tessPath}\n')
         for i in range(0, len(self.voices_list)):
                f.write(f'{self.voices_list[i]}, ' if i != len(self.voices_list) - 1 else f'{self.voices_list[i]}')
         f.close()
      # # print(self.checkBoxState)
      # if self.checkBoxState:
      #    with open("config.helper", "w") as f:
      #       f.write(str(self.dial.value()))
      #       f.write("\nTrue")
      #       if self.voice_gender == 0:
      #          f.write("\nMale")
      #       else:
      #          f.write("\nFemale")
      #       f.close()
      #    # # print("dd")
      # else:
      #    with open("config.helper", "w") as f:
      #       f.write(str(self.dial.value()))
      #       f.write("\nFalse")
      #       if self.voice_gender == 0:
      #          f.write("\nMale")
      #       else:
      #          f.write("\nFemale")
      #       f.write("on" if self.theme_status else "off")
      #       f.close()

      with open("res/known_words_list.helper", "w") as f:
         for i in self.known_words_list:
            if str(self.known_words_list[-1]) == str(i):
               f.write(str(i) + ",\n")
            else:
               f.write(str(i) + ",\n")

            # f.close()

   def change_speed(self):
      '''if self.checkBoxState:
         with open("config.helper", "w") as f:
            f.write(str(self.dial.value()))
            f.write("\nTrue")
            f.close()
      else:
         with open("config.helper", "w") as f:
            f.write(str(self.dial.value()))
            f.write("\nFalse")
            f.close()'''

      self.quit()

   def checkBoxChangedAction(self):
      self.checkBoxState = self.checkbox.isChecked()

   def split(self, word):
      return [char for char in word]

   def update_speed_file(self):
         with open("res/config.helper", "w") as f:
            f.write(str(self.dial.value()))
            f.write("\nFalse")
            f.write(f'')
            f.write(f'{self.totalWords}')
            
            f.close()

   def change_dial_value(self):
      self.dial_value.setText(str(self.dial.value()))
      self.newVoiceRate = self.dial.value()
      # ## print(self.dial.value())

   def speak(self, text):
      self.engine.say(text)
      self.engine.runAndWait()



   def read(self):
      # print(self.voice_index)
      self.note = self.note_input.toPlainText().replace('(', ' ( ').replace(':', ' : ').replace('-', ' - ').replace(')', ' ) ')
      self.note = self.note.split() 
      voices = self.engine.getProperty('voices')
      self.engine.setProperty('voice', self.voices[int(self.voice_index)].id)
      # voices.name == 'DAVID'
      # print("nvr: " + str(self.newVoiceRate))

      self.engine.setProperty('rate', self.newVoiceRate)
      # # print(self.newVoiceRate)

      # noinspection PySimplifyBooleanCheck
      self.current_index = 0

      self.last_word = "-"
      self.next_word = ""
      self.last_word_lab.setText(self.last_word)
      for i in self.note:

         self.current_word = str(i)
         if len(self.note) > 0 and self.current_index != 1:
            self.last_word = self.note[self.current_index - 1] if self.current_index != 0 else "-"
            self.next_word = self.note[self.current_index + 1] if self.current_index != len(self.note) - 1 else "-"
            self.before_last_word = self.note[self.current_index - 2]
            self.totalWords += 1
            self.curr_word.setText(self.current_word)
            self.next_word_lab.setText(self.next_word)
            self.last_word_lab.setText(self.last_word)
            self.words_written.setText(f'{self.totalWords} words written')
         # making a loop

         if "." in i:

            if len(i) <= 2:
               self.speak(i)
               self.speak("fullstop")
               time.sleep(0.25)


            if len(i) < 5:
               self.speak(i)
               self.speak("fullstop")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("fullstop")
               time.sleep(2.3)
            elif len(i) <= 8:
               self.speak(i)
               self.speak("fullstop")
               time.sleep(2.8)
            else:
               self.speak(i)
               self.speak("fullstop")



         elif "," in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("comma")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("comma")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("comma")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)



         elif "!" in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("Exclamation")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("Exclamation")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("Exclamation")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)


         elif "(" in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("Left bracket")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("Left bracket")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("Left bracket")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)

         elif ")" in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("Right bracket")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("Right bracket")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("Right bracket")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)

         elif ":" in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("colon")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("colon")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("colon")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)

         elif "-" in i:

            if len(i) < 5:
               self.speak(i)
               self.speak("hyphen")
               time.sleep(1)


            elif len(i) < 8:
               self.speak(i)
               self.speak("hyphen")
               time.sleep(2.3)

            else:
               self.speak(i)
               self.speak("hyphen")

               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)

         else:

            if len(i) < 5:
               self.speak(i)
               time.sleep(1)


            elif len(i) <= 8:
               self.speak(i)
               time.sleep(2.3)
            else:
               self.speak(i)
               # print(i)
               split_list = self.split(i)
               if not i.lower() in self.known_words_list:
                  for i in split_list:
                     self.speak(i)
         self.current_index += 1

# Triggers

try:
   app = QtWidgets.QApplication(sys.argv)
   window = Ui()
   window.show()
   app.exec_()
except Exception as e:
   print(f"error: {e}")
